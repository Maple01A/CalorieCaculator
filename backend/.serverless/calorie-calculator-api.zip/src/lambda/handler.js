"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.options = exports.updateUserSettings = exports.getUserSettings = exports.getDailySummary = exports.addMealRecord = exports.getFoodById = exports.searchFoods = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const FOODS_TABLE = process.env.FOODS_TABLE || 'CalorieCalculator-Foods';
const MEALS_TABLE = process.env.MEALS_TABLE || 'CalorieCalculator-Meals';
const USERS_TABLE = process.env.USERS_TABLE || 'CalorieCalculator-Users';
// CORSヘッダー
const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Content-Type': 'application/json',
};
// レスポンスヘルパー
const response = (statusCode, body) => ({
    statusCode,
    headers,
    body: JSON.stringify(body),
});
// 食品検索
const searchFoods = async (event) => {
    try {
        const query = event.queryStringParameters?.query || '';
        if (!query) {
            return response(400, { error: '検索クエリが必要です' });
        }
        const result = await docClient.send(new lib_dynamodb_1.ScanCommand({
            TableName: FOODS_TABLE,
            FilterExpression: 'contains(#name, :query)',
            ExpressionAttributeNames: { '#name': 'name' },
            ExpressionAttributeValues: { ':query': query },
        }));
        return response(200, { foods: result.Items || [] });
    }
    catch (error) {
        console.error('Error searching foods:', error);
        return response(500, { error: '食品検索中にエラーが発生しました' });
    }
};
exports.searchFoods = searchFoods;
// 食品詳細取得
const getFoodById = async (event) => {
    try {
        const foodId = event.pathParameters?.id;
        if (!foodId) {
            return response(400, { error: '食品IDが必要です' });
        }
        const result = await docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: FOODS_TABLE,
            Key: { id: foodId },
        }));
        if (!result.Item) {
            return response(404, { error: '食品が見つかりません' });
        }
        return response(200, result.Item);
    }
    catch (error) {
        console.error('Error getting food:', error);
        return response(500, { error: '食品取得中にエラーが発生しました' });
    }
};
exports.getFoodById = getFoodById;
// 食事記録追加
const addMealRecord = async (event) => {
    try {
        const body = JSON.parse(event.body || '{}');
        const { userId, foodId, foodName, amount, calories, protein, carbs, fat, mealType, timestamp } = body;
        if (!userId || !foodId || !amount || !mealType) {
            return response(400, { error: '必須フィールドが不足しています' });
        }
        const mealId = `${userId}-${Date.now()}`;
        const mealRecord = {
            id: mealId,
            userId,
            foodId,
            foodName: foodName || '',
            amount,
            calories: calories || 0,
            protein: protein || 0,
            carbs: carbs || 0,
            fat: fat || 0,
            mealType,
            timestamp: timestamp || new Date().toISOString(),
            createdAt: new Date().toISOString(),
        };
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: MEALS_TABLE,
            Item: mealRecord,
        }));
        return response(201, { id: mealId, message: '食事記録を追加しました' });
    }
    catch (error) {
        console.error('Error adding meal:', error);
        return response(500, { error: '食事記録追加中にエラーが発生しました' });
    }
};
exports.addMealRecord = addMealRecord;
// 日別サマリー取得
const getDailySummary = async (event) => {
    try {
        const userId = event.pathParameters?.userId;
        const date = event.pathParameters?.date;
        if (!userId || !date) {
            return response(400, { error: 'ユーザーIDと日付が必要です' });
        }
        // その日の開始と終了のタイムスタンプ
        const startOfDay = `${date}T00:00:00.000Z`;
        const endOfDay = `${date}T23:59:59.999Z`;
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: MEALS_TABLE,
            IndexName: 'UserIdTimestampIndex',
            KeyConditionExpression: 'userId = :userId AND #timestamp BETWEEN :start AND :end',
            ExpressionAttributeNames: { '#timestamp': 'timestamp' },
            ExpressionAttributeValues: {
                ':userId': userId,
                ':start': startOfDay,
                ':end': endOfDay,
            },
        }));
        const meals = result.Items || [];
        // 栄養情報の合計を計算
        let totalCalories = 0;
        let totalProtein = 0;
        let totalCarbs = 0;
        let totalFat = 0;
        // 食事記録に栄養情報が含まれている場合はそれを使用し、
        // ない場合は食品マスタから取得
        const mealsWithFoodInfo = [];
        for (const meal of meals) {
            // すでに栄養情報が保存されている場合
            if (meal.calories !== undefined && meal.foodName) {
                totalCalories += meal.calories || 0;
                totalProtein += meal.protein || 0;
                totalCarbs += meal.carbs || 0;
                totalFat += meal.fat || 0;
                mealsWithFoodInfo.push({
                    ...meal,
                });
            }
            else {
                // 古いデータの場合は食品マスタから取得
                const foodResult = await docClient.send(new lib_dynamodb_1.GetCommand({
                    TableName: FOODS_TABLE,
                    Key: { id: meal.foodId },
                }));
                if (foodResult.Item) {
                    const food = foodResult.Item;
                    const multiplier = meal.amount / 100;
                    const mealCalories = Math.round(food.caloriesPer100g * multiplier);
                    const mealProtein = Math.round((food.protein || 0) * multiplier * 10) / 10;
                    const mealCarbs = Math.round((food.carbs || 0) * multiplier * 10) / 10;
                    const mealFat = Math.round((food.fat || 0) * multiplier * 10) / 10;
                    totalCalories += mealCalories;
                    totalProtein += mealProtein;
                    totalCarbs += mealCarbs;
                    totalFat += mealFat;
                    mealsWithFoodInfo.push({
                        ...meal,
                        foodName: food.name,
                        calories: mealCalories,
                        protein: mealProtein,
                        carbs: mealCarbs,
                        fat: mealFat,
                    });
                }
            }
        }
        return response(200, {
            date,
            meals: mealsWithFoodInfo,
            summary: {
                totalCalories: Math.round(totalCalories),
                totalProtein: Math.round(totalProtein * 10) / 10,
                totalCarbs: Math.round(totalCarbs * 10) / 10,
                totalFat: Math.round(totalFat * 10) / 10,
                mealCount: mealsWithFoodInfo.length,
            },
        });
    }
    catch (error) {
        console.error('Error getting daily summary:', error);
        return response(500, { error: '日別サマリー取得中にエラーが発生しました' });
    }
};
exports.getDailySummary = getDailySummary;
// ユーザー設定取得
const getUserSettings = async (event) => {
    try {
        const userId = event.pathParameters?.userId;
        if (!userId) {
            return response(400, { error: 'ユーザーIDが必要です' });
        }
        const result = await docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: USERS_TABLE,
            Key: { id: userId },
        }));
        if (!result.Item) {
            // デフォルト設定を返す
            return response(200, {
                id: userId,
                dailyCalorieGoal: 2000,
                createdAt: new Date().toISOString(),
            });
        }
        return response(200, result.Item);
    }
    catch (error) {
        console.error('Error getting user settings:', error);
        return response(500, { error: 'ユーザー設定取得中にエラーが発生しました' });
    }
};
exports.getUserSettings = getUserSettings;
// ユーザー設定更新
const updateUserSettings = async (event) => {
    try {
        const userId = event.pathParameters?.userId;
        const body = JSON.parse(event.body || '{}');
        if (!userId) {
            return response(400, { error: 'ユーザーIDが必要です' });
        }
        const settings = {
            id: userId,
            ...body,
            updatedAt: new Date().toISOString(),
        };
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: USERS_TABLE,
            Item: settings,
        }));
        return response(200, { message: 'ユーザー設定を更新しました', settings });
    }
    catch (error) {
        console.error('Error updating user settings:', error);
        return response(500, { error: 'ユーザー設定更新中にエラーが発生しました' });
    }
};
exports.updateUserSettings = updateUserSettings;
// OPTIONSリクエスト処理
const options = async () => {
    return response(200, {});
};
exports.options = options;
