"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.changePassword = exports.getCurrentUser = exports.signIn = exports.signUp = exports.verifyToken = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_ses_1 = require("@aws-sdk/client-ses");
const crypto = __importStar(require("crypto"));
const jwt = __importStar(require("jsonwebtoken"));
const bcrypt = __importStar(require("bcryptjs"));
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const sesClient = new client_ses_1.SESClient({ region: process.env.AWS_REGION || 'ap-northeast-1' });
const USERS_TABLE = process.env.USERS_TABLE || 'CalorieCalculator-Users';
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-this-in-production';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const FROM_EMAIL = process.env.FROM_EMAIL || 'noreply@example.com';
// CORSヘッダー
const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
    'Content-Type': 'application/json',
};
// レスポンスヘルパー
const response = (statusCode, body) => ({
    statusCode,
    headers,
    body: JSON.stringify(body),
});
// JWTトークン生成
const generateToken = (userId, email) => {
    return jwt.sign({ userId, email }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
};
// JWTトークン検証
const verifyToken = (token) => {
    try {
        return jwt.verify(token, JWT_SECRET);
    }
    catch (error) {
        throw new Error('無効なトークンです');
    }
};
exports.verifyToken = verifyToken;
// パスワードハッシュ化
const hashPassword = async (password) => {
    return await bcrypt.hash(password, 10);
};
// パスワード検証
const comparePassword = async (password, hash) => {
    return await bcrypt.compare(password, hash);
};
// メールアドレスでユーザーを検索
const getUserByEmail = async (email) => {
    const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
        TableName: USERS_TABLE,
        IndexName: 'EmailIndex',
        KeyConditionExpression: 'email = :email',
        ExpressionAttributeValues: { ':email': email },
    }));
    return result.Items && result.Items.length > 0 ? result.Items[0] : null;
};
// 確認メール送信
const sendWelcomeEmail = async (email, displayName) => {
    try {
        const params = {
            Source: FROM_EMAIL,
            Destination: {
                ToAddresses: [email],
            },
            Message: {
                Subject: {
                    Data: 'カロリー計算アプリへようこそ！',
                    Charset: 'UTF-8',
                },
                Body: {
                    Html: {
                        Data: `
              <!DOCTYPE html>
              <html>
              <head>
                <meta charset="UTF-8">
              </head>
              <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                  <h1 style="color: #007AFF;">カロリー計算アプリ</h1>
                  <p>こんにちは、${displayName}さん</p>
                  <p>カロリー計算アプリへようこそ！アカウント登録ありがとうございます。</p>
                  <p>このアプリでは、以下の機能をご利用いただけます：</p>
                  <ul>
                    <li>食事の記録と自動カロリー計算</li>
                    <li>日々のカロリー推移の確認</li>
                    <li>食品データベースの検索</li>
                    <li>クラウドでのデータ同期</li>
                  </ul>
                  <p>健康的な食生活をサポートします！</p>
                  <p style="margin-top: 30px; color: #666; font-size: 12px;">
                    このメールに心当たりがない場合は、お手数ですが削除してください。
                  </p>
                </div>
              </body>
              </html>
            `,
                        Charset: 'UTF-8',
                    },
                    Text: {
                        Data: `
こんにちは、${displayName}さん

カロリー計算アプリへようこそ！アカウント登録ありがとうございます。

このアプリでは、以下の機能をご利用いただけます：
- 食事の記録と自動カロリー計算
- 日々のカロリー推移の確認
- 食品データベースの検索
- クラウドでのデータ同期

健康的な食生活をサポートします！

このメールに心当たりがない場合は、お手数ですが削除してください。
            `,
                        Charset: 'UTF-8',
                    },
                },
            },
        };
        await sesClient.send(new client_ses_1.SendEmailCommand(params));
        console.log('Welcome email sent to:', email);
    }
    catch (error) {
        console.error('Failed to send welcome email:', error);
        // メール送信失敗はエラーとして扱わない（ユーザー登録自体は成功させる）
    }
};
// 新規登録
const signUp = async (event) => {
    try {
        const body = JSON.parse(event.body || '{}');
        const { email, password, displayName } = body;
        // バリデーション
        if (!email || !password) {
            return response(400, { error: 'メールアドレスとパスワードは必須です' });
        }
        if (password.length < 6) {
            return response(400, { error: 'パスワードは6文字以上で設定してください' });
        }
        // メールアドレス形式チェック
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return response(400, { error: '有効なメールアドレスを入力してください' });
        }
        // 既存ユーザーチェック
        const existingUser = await getUserByEmail(email);
        if (existingUser) {
            return response(409, { error: 'このメールアドレスは既に登録されています' });
        }
        // ユーザーID生成
        const userId = crypto.randomUUID();
        // パスワードハッシュ化
        const passwordHash = await hashPassword(password);
        // ユーザー作成（デフォルト設定を含む）
        const user = {
            id: userId,
            email,
            displayName: displayName || email.split('@')[0],
            passwordHash,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            // デフォルト設定
            dailyCalorieGoal: 2000,
            height: 170,
            weight: 70,
            age: 20,
            gender: 'male',
        };
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: USERS_TABLE,
            Item: user,
        }));
        // 確認メールを送信（非同期）
        sendWelcomeEmail(email, user.displayName).catch(error => {
            console.error('Email sending failed:', error);
        });
        // JWTトークン生成
        const token = generateToken(userId, email);
        // レスポンス（パスワードハッシュは除外）
        const { passwordHash: _, ...userWithoutPassword } = user;
        return response(201, {
            message: 'ユーザー登録が完了しました',
            token,
            user: userWithoutPassword,
        });
    }
    catch (error) {
        console.error('Sign up error:', error);
        return response(500, { error: 'ユーザー登録中にエラーが発生しました' });
    }
};
exports.signUp = signUp;
// ログイン
const signIn = async (event) => {
    try {
        const body = JSON.parse(event.body || '{}');
        const { email, password } = body;
        // バリデーション
        if (!email || !password) {
            return response(400, { error: 'メールアドレスとパスワードを入力してください' });
        }
        // ユーザー検索
        const user = await getUserByEmail(email);
        if (!user) {
            return response(401, { error: 'メールアドレスまたはパスワードが正しくありません' });
        }
        // パスワード検証
        const isPasswordValid = await comparePassword(password, user.passwordHash);
        if (!isPasswordValid) {
            return response(401, { error: 'メールアドレスまたはパスワードが正しくありません' });
        }
        // 最終ログイン日時更新（UpdateCommandで既存データを保持）
        await docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: USERS_TABLE,
            Key: { id: user.id },
            UpdateExpression: 'SET lastLoginAt = :lastLoginAt, updatedAt = :updatedAt',
            ExpressionAttributeValues: {
                ':lastLoginAt': new Date().toISOString(),
                ':updatedAt': new Date().toISOString(),
            },
        }));
        // JWTトークン生成
        const token = generateToken(user.id, email);
        // レスポンス（パスワードハッシュは除外）
        const { passwordHash: _, ...userWithoutPassword } = user;
        return response(200, {
            message: 'ログインしました',
            token,
            user: userWithoutPassword,
        });
    }
    catch (error) {
        console.error('Sign in error:', error);
        return response(500, { error: 'ログイン中にエラーが発生しました' });
    }
};
exports.signIn = signIn;
// 現在のユーザー情報取得（認証必須）
const getCurrentUser = async (event) => {
    try {
        // Authorizationヘッダーからトークン取得
        const authHeader = event.headers.Authorization || event.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return response(401, { error: '認証トークンが必要です' });
        }
        const token = authHeader.substring(7);
        // トークン検証
        const decoded = (0, exports.verifyToken)(token);
        const userId = decoded.userId;
        // ユーザー情報取得
        const result = await docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: USERS_TABLE,
            Key: { id: userId },
        }));
        if (!result.Item) {
            return response(404, { error: 'ユーザーが見つかりません' });
        }
        // レスポンス（パスワードハッシュは除外）
        const { passwordHash: _, ...userWithoutPassword } = result.Item;
        return response(200, { user: userWithoutPassword });
    }
    catch (error) {
        console.error('Get current user error:', error);
        if (error.message === '無効なトークンです' || error.name === 'JsonWebTokenError') {
            return response(401, { error: '認証トークンが無効です' });
        }
        if (error.name === 'TokenExpiredError') {
            return response(401, { error: '認証トークンの有効期限が切れています' });
        }
        return response(500, { error: 'ユーザー情報取得中にエラーが発生しました' });
    }
};
exports.getCurrentUser = getCurrentUser;
// パスワード変更（認証必須）
const changePassword = async (event) => {
    try {
        // 認証トークン検証
        const authHeader = event.headers.Authorization || event.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return response(401, { error: '認証トークンが必要です' });
        }
        const token = authHeader.substring(7);
        const decoded = (0, exports.verifyToken)(token);
        const userId = decoded.userId;
        // リクエストボディ取得
        const body = JSON.parse(event.body || '{}');
        const { currentPassword, newPassword } = body;
        if (!currentPassword || !newPassword) {
            return response(400, { error: '現在のパスワードと新しいパスワードを入力してください' });
        }
        if (newPassword.length < 6) {
            return response(400, { error: '新しいパスワードは6文字以上で設定してください' });
        }
        // ユーザー情報取得
        const result = await docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: USERS_TABLE,
            Key: { id: userId },
        }));
        if (!result.Item) {
            return response(404, { error: 'ユーザーが見つかりません' });
        }
        const user = result.Item;
        // 現在のパスワード検証
        const isCurrentPasswordValid = await comparePassword(currentPassword, user.passwordHash);
        if (!isCurrentPasswordValid) {
            return response(401, { error: '現在のパスワードが正しくありません' });
        }
        // 新しいパスワードをハッシュ化
        const newPasswordHash = await hashPassword(newPassword);
        // パスワード更新
        await docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: USERS_TABLE,
            Item: {
                ...user,
                passwordHash: newPasswordHash,
                updatedAt: new Date().toISOString(),
            },
        }));
        return response(200, { message: 'パスワードを変更しました' });
    }
    catch (error) {
        console.error('Change password error:', error);
        if (error.message === '無効なトークンです' || error.name === 'JsonWebTokenError') {
            return response(401, { error: '認証トークンが無効です' });
        }
        return response(500, { error: 'パスワード変更中にエラーが発生しました' });
    }
};
exports.changePassword = changePassword;
